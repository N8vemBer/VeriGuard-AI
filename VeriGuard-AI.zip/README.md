# VeriGuard AI: Deception Mitigation Framework for LLMs

## 🔍 Overview
VeriGuard AI is a research framework designed to identify and reduce deceptive outputs in Large Language Models (LLMs). It evaluates hallucinations, flawed reasoning, misleading citations, and overconfidence — and mitigates them using three techniques: self-reflection prompting, cross-verification with trusted sources, and confidence calibration.

## 🛠 Framework Components
- `self_reflection.py`: Adds internal consistency prompts to LLM responses.
- `cross_verification.py`: Validates claims using external databases.
- `confidence_calibration.py`: Calibrates model confidence using temperature scaling.

## 🚀 How to Use
1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Run a sample mitigation pipeline:
```bash
python framework/self_reflection.py
```

3. Open the demo notebook:
```bash
cd notebooks && jupyter notebook deception_mitigation_demo.ipynb
```

## 📁 Data
The `data/` folder includes sample prompts across law, medicine, and finance for benchmarking.

## 📊 Results
This repository supports experiments validating a ~49% reduction in deception across GPT-4, LLaMA 3, and Mistral.

---

© 2025 Boecyàn Bourgage | UC Berkeley AgentX Competition
